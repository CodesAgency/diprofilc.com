var jumbotronLi ={
    titleProvinci:  document.getElementById('titleProvinci'),
    siteOne:        document.getElementById('siteOne'),
    siteTwo:        document.getElementById('siteTwo'),
    siteThree:      document.getElementById('siteThree'),
    siteFour:       document.getElementById('siteFour'),
    siteFive:       document.getElementById('siteFive'),
    siteSix:        document.getElementById('siteSix'),
    siteSeven:      document.getElementById('siteSeven'),
    miniShowProvs:  document.getElementById('miniShowProvs')
}

function changeText(prov, s1, s2, s3, s4, s5 ,s6 ,s7){
    jumbotronLi.titleProvinci.innerHTML = prov;
    jumbotronLi.siteOne.innerHTML   =       s1;
    jumbotronLi.siteTwo.innerHTML   =       s2;
    jumbotronLi.siteThree.innerHTML =       s3;
    jumbotronLi.siteFour.innerHTML  =       s4;
    jumbotronLi.siteFive.innerHTML  =       s5;
    jumbotronLi.siteSix.innerHTML   =       s6;
    jumbotronLi.siteSeven.innerHTML =       s7;
   
}




