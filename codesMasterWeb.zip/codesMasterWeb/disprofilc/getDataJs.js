//toma de datos para variables Li del mapa
//aquí se esta llegando a las variables del div #map {INICIO}
const provinciasEcuador = {
    costa: {
        guayas:     document.getElementById('l1a'),
        santaElena: document.getElementById('l2a'),
        elOro:      document.getElementById('l3a'),
        manabi:     document.getElementById('l4a'),
    },

    sierra: {
        canar:      document.getElementById('l1b'),
        cotopaxi:   document.getElementById('l2b'),
        imbabura:   document.getElementById('l3b'),
        bolivar:    document.getElementById('l4b'),
        azuay:      document.getElementById('l5b'),
        loja:       document.getElementById('l6b'),
        pichincha:  document.getElementById('l7b')
    }
}

let imgProvEcu = {
    costa: {
        guayas:     document.getElementById('guayas'),
        santaElena: document.getElementById('santaElena'),
        elOro:      document.getElementById('elOro'),
        manabi:     document.getElementById('manabi')
    },

    sierra: {
        canar:      document.getElementById('cañar'),
        cotopaxi:   document.getElementById('cotopaxi'),
        imbabura:   document.getElementById('imbabura'),
        bolivar:    document.getElementById('bolivar'),
        azuay:      document.getElementById('azuay'),
        loja:       document.getElementById('loja'),
        pichincha:  document.getElementById('pichincha')
    }

}

//aquí se esta llegando a las variables del div #map {FIN}

function showCosta(nameAnimation , horv){
 //guayas
 imgProvEcu.costa.guayas.style.animation =       nameAnimation;
 imgProvEcu.costa.guayas.style.visibility =      horv;
 //santa elena
 imgProvEcu.costa.santaElena.style.animation =    nameAnimation;
 imgProvEcu.costa.santaElena.style.visibility =  horv;
 //el oro
 imgProvEcu.costa.elOro.style.animation =         nameAnimation;
 imgProvEcu.costa.elOro.style.visibility =       horv;
 //manabi
 imgProvEcu.costa.manabi.style.animation =        nameAnimation;
 imgProvEcu.costa.manabi.style.visibility =      horv;
}

function showSierra(nameAnimation , horv){
//cañar
imgProvEcu.sierra.canar.style.animation = nameAnimation;
imgProvEcu.sierra.canar.style.visibility = horv;
//cotopaxi
imgProvEcu.sierra.cotopaxi.style.animation = nameAnimation;
imgProvEcu.sierra.cotopaxi.style.visibility = horv;
//imbabura
imgProvEcu.sierra.imbabura.style.animation = nameAnimation;
imgProvEcu.sierra.imbabura.style.visibility = horv;
//bolivar
imgProvEcu.sierra.bolivar.style.animation = nameAnimation;
imgProvEcu.sierra.bolivar.style.visibility = horv;
//azuay
imgProvEcu.sierra.azuay.style.animation = nameAnimation;
imgProvEcu.sierra.azuay.style.visibility = horv;
//loja
imgProvEcu.sierra.loja.style.animation = nameAnimation;
imgProvEcu.sierra.loja.style.visibility = horv;
//pichincha
imgProvEcu.sierra.pichincha.style.animation = nameAnimation;
imgProvEcu.sierra.pichincha.style.visibility = horv;
}

switch (choiceProvsEcuador) {
    case choiceProvsEcuador.costa.addEventListener('click', showAllCosta):
        function showAllCosta(){
           showCosta();
        }
        
        break;
        case choiceProvsEcuador.sierra.addEventListener('click', showAllSierra):
        function showAllSierra(){
            showSierra();
        }
        
        break;
    default:
        break;
}

//aquí se esta llegando a las variables del div #map {FIN}
//casos costa
switch (provinciasEcuador) {
    case provinciasEcuador.costa.guayas.addEventListener('click', activeGuayas):
        function activeGuayas(){
            imgProvEcu.costa.guayas.style.animation = "showGuayas 1s linear 1";
            imgProvEcu.costa.guayas.style.visibility = "visible";        
        }
        break;
    case provinciasEcuador.costa.santaElena.addEventListener('click', activeSantaELena):
        function activeSantaELena(){
            imgProvEcu.costa.santaElena.style.animation = "showSantaElena 1s linear 1";
            imgProvEcu.costa.santaElena.style.visibility = "visible";
        }
       break;
    case provinciasEcuador.costa.elOro.addEventListener('click', activeElOro):
        function activeElOro(){
            imgProvEcu.costa.elOro.style.animation = "showElOro 1s linear 1";
            imgProvEcu.costa.elOro.style.visibility = "visible";
        }
       break;
    case provinciasEcuador.costa.manabi.addEventListener('click', activeManabi):
       function activeManabi(){
           imgProvEcu.costa.manabi.style.animation = "showManabi 1s linear 1";
           imgProvEcu.costa.manabi.style.visibility = "visible";
       }
    
    default:
        break;
}
//Casos Sierra
switch (provinciasEcuador) {
    case provinciasEcuador.sierra.canar.addEventListener('click', activeCanar):
        function activeCanar(){
            imgProvEcu.sierra.canar.style.animation = "showCañar 1s linear 1";
            imgProvEcu.sierra.canar.style.visibility = "visible";
        }
    case provinciasEcuador.sierra.cotopaxi.addEventListener('click', activeCotopaxi):
        function activeCotopaxi(){
            imgProvEcu.sierra.cotopaxi.style.animation = "showCotopaxi 1s linear 1";
            imgProvEcu.sierra.cotopaxi.style.visibility = "visible";
        }
      break;
    case provinciasEcuador.sierra.imbabura.addEventListener('click', activeImbabura):
        function activeImbabura(){
            imgProvEcu.sierra.imbabura.style.animation = "showImbabura 1s linear 1";
            imgProvEcu.sierra.imbabura.style.visibility = "visible";
        }
      break;
    case provinciasEcuador.sierra.bolivar.addEventListener('click', activeBolivar):
        function activeBolivar(){
            imgProvEcu.sierra.bolivar.style.animation = "showBolivar 1s linear 1";
            imgProvEcu.sierra.bolivar.style.visibility = "visible";
        }
    case provinciasEcuador.sierra.azuay.addEventListener('click', activeAzuay):
        function activeAzuay(){
            imgProvEcu.sierra.azuay.style.animation = "showBolivar 1s linear 1";
            imgProvEcu.sierra.azuay.style.visibility = "visible";
        }
      break;
    case provinciasEcuador.sierra.loja.addEventListener('click', activeLoja):
        function activeLoja(){
            imgProvEcu.sierra.loja.style.animation = "showLoja 1s linear 1";
            imgProvEcu.sierra.loja.style.visibility = "visible";
        }
      break;
    case provinciasEcuador.sierra.pichincha.addEventListener('click', activePichincha):
      function activePichincha(){
          imgProvEcu.sierra.pichincha.style.animation = "showPichincha 1s linear 1";
          imgProvEcu.sierra.pichincha.style.visibility = "visible";
      }
    break;

    default:
        break;
}

